-- Lua 모듈 불러오기
local timer = require "timer"

--Settings
local swapItemKey = Keyboard.KEY_LEFT_SHIFT --Which keyboard key swaps items
local controllerMode = false --Changing this to true changes input to the item drop button (finnicky)

local ChaosGreed = RegisterMod("ChaosGreed", 1)

-- 아이템 등록
local chiggers_item = Isaac.GetItemIdByName("Larval Therapy")
local backpack_item = Isaac.GetItemIdByName("Backpack")
local symbolp_item = Isaac.GetItemIdByName("Symbol_Of_Babylonia")
local farsp_item = Isaac.GetItemIdByName("Farss_Golden_Goblet")
local rosettap_item = Isaac.GetItemIdByName("Rosetta_Stone")
local quickchaos_item = Isaac.GetItemIdByName("Rank-Up-Magic Quick Chaos")
local skipforce_item = Isaac.GetItemIdByName("Rank-Up-Magic Skip Force")
local deathdoubleforce_item = Isaac.GetItemIdByName("Rank-Up-Magic Death Double Force")
local mono_item = Isaac.GetItemIdByName("Monolelium")
local pride_item = Isaac.GetItemIdByName("Eye with Full of Pride")
local sloth_item = Isaac.GetItemIdByName("A Slothful Foot")
local greed_item = Isaac.GetItemIdByName("The Hand of Greed")
local gluttony_item = Isaac.GetItemIdByName("A Mouth-eaten Mouth")
local envy_item = Isaac.GetItemIdByName("Tongue with Envy")
local spice_item = Isaac.GetItemIdByName("Spice")
local scroll_item = Isaac.GetItemIdByName("Scroll For Chaos")
local lol_item = Isaac.GetItemIdByName("League of Legends")
local hippo_item = Isaac.GetItemIdByName("The Small Hippo")
local raven_item = Isaac.GetItemIdByName("The Small Raven")
local toy_item = Isaac.GetItemIdByName("The Small Toy")
local ascroll_item = Isaac.GetItemIdByName("Amazing Chaos Scroll")
local soulshave_item = Isaac.GetItemIdByName("Rank-Up-Magic Soul Shave Force")

-- 기존 아이템 코드 이용 (모드 아이템 분리를 쉽게 하기 위해)
local werry_item = 1
local powerbond_item = 5
local limiterremoval_item = 6
local restore_item = 19 -- 붐
local chaos_item = 20 -- 초월
local symbol_item = 21
local fars_item = 26
local rosetta_item = 54
local cov_item = 56
local eter_item = 171
local stopwatch_item = 288
local cipher_item = 294
local astral_item = 295
local raptor_item = 298 
local gamble_item = 391
--local infestedhead_item = 32 

-- 카드 등록
local hermit_stars_card = Isaac.GetCardIdByName("HermitStars")

-- 코스튬 등록
local morphine_costume = Isaac.GetCostumeIdByPath("gfx/characters/costumes/morphine.anm2")
local tramp_costume = Isaac.GetCostumeIdByPath("gfx/characters/costumes/tramp_of_babylon.anm2")

-- 각종 변수
local hasMorphine = false

local hasBackpack = false
local heldItem = 0
local heldItemCharge = 0
local storedItem = 0
local storedItemCharge = 0
local batteryCharge = 0

local swapBuffer = 0
local useItemFrame = 0

local config = Isaac.GetItemConfig()
local storedItemSprite = Sprite()
storedItemSprite:Load("backpack_storeditem.anm2")
storedItemSprite:Play("Idle")

local werryContinue = 0
local powerBondContinue = 0
local limiterRemovalContinue = 0
local covContinue = 0
local quickChaosContinue = 0
local megaContinue = 0
local stopwatchContinue = 0
local cipherContinue = 0
local hippoContinue = 0
local isWerryTimeOut = true
local isPowerBondTimeOut = true
local isLimiterRemovalTimeOut = true
local isCovTimeOut = true
local isQuickChaosTimeOut = true
local isMegaBlastTimeOut = true
local isWatchTimeOut = true
local isHippoTimeOut = true

local errorTeleportStartedFrame = -1
local UGTeleportStartedFrame = -1

local isforcesuccess = 0
local isamplisuccess = 0

local shadowremove = false
local haslumen = false
local pearlrandom = math.random(0,3)
local eterbanji = 0
local roomiscleared = 0
local roomseedisold = 0
local ranscroll = 0

local curseroom = {
	21,
	22,
	23,
	24,
	26,
	27,
	28,
	29,
	30,
	31,
	32,
	51,
	54,
	81,
	82,
	133,
	134,
	179,
	212,
	241,
	249,
	255,
	411
}
local specialitem = {
	5,
	18,
	30,
	31,
	64,
	69,
	119,
	157,
	169,
	172,
	182,
	203,
	221,
	223,
	261,
	286,
	310,
	311,
	313,
	331,
	339,
	346,
	360,
	389,
	393,
	415,
	419,
	424,
	496,
	500,
	503
}
local attacktype = {
	68,
	114,
	118,
	168,
	395
}
local spiceused = 0
local spiceuse = false
local cipheruse = false
local soulshaveuse = false
local soulshaveContinue = 0

function getFlag(arr, currentFlag) -- 눈물 상태 함수
    number = currentFlag;
   
    for i = 1, #arr do
        number = number | 2^(arr[i] - 1);
    end
   
    return number;
end

function ChaosGreed:Item1(player, cacheFlag) -- items.xml의 cacheFlag를 불러오는 과정
	local player = Isaac.GetPlayer(0)

	if (cacheFlag == CacheFlag.CACHE_DAMAGE) then -- 아이템 획득 시 cacheFlag가 데미지면
		if player:HasCollectible(22) then -- 22를 획득했을 시
			player.Damage = player.Damage + 6 -- 데미지 +3
		end
		if player:HasCollectible(241) then -- 241를 획득했을 시
			player.Damage = player.Damage + 4 -- 데미지 +4
		end
		if player:HasCollectible(249) then -- 249 획득했을 시
			player.Damage = player.Damage + 4 -- 데미지 +4
		end
		if player:HasCollectible(255) then -- 255 획득했을 시
			player.Damage = player.Damage + 4 -- 데미지 +4
		end
		if player:HasCollectible(176) then -- 176 획득했을 시
			player.Damage = player.Damage + 9.99 -- 데미지 +9.99
		end
		if player:HasCollectible(25) then -- 25를 획득했을 시
			player.Damage = player.Damage + (2 * player:GetCollectibleNum(25)) -- 2의 데미지를 25를 획득한 수 만큼 증가
		end
		if player:HasCollectible(241) and player:HasCollectible(249) and player:HasCollectible(255) then -- 모두 획득 시
			player.Damage = player.Damage + 12 -- 데미지 +12
		end
		if player:HasCollectible(317) then
			player.Damage = player.Damage + 3
		end
		if player:HasCollectible(90) then
			player.Damage = player.Damage + 5
		end
		if player:HasCollectible(27) then
			player.Damage = player.Damage + 5
		end
		if isWerryTimeOut == false then -- 아직 지속 시간이라면
			player.Damage = player.Damage + 30
		end
		if isCovTimeOut == false then
			player.Damage = player.Damage + 20
		end
		if isMegaBlastTimeOut == false then
			player.Damage = player.Damage + 200
		end
		if isHippoTimeOut == false then
			player.Damage = player.Damage + 1000
		end
		player.Damage = player.Damage + (10 * isamplisuccess) + (5 * isforcesuccess) + ranscroll
		if spiceuse == true then
			player.Damage = player.Damage - spiceused
		end
		if player:HasCollectible(22) and player:HasCollectible(23) and player:HasCollectible(24) then -- 22 23 24를 모두 획득 시
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then -- 149를 획득했으면
				player.Damage = ((player.Damage-40)*2)+40 -- 40 먼저 빼고 2를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 2 -- 그냥 2배
			end
		end
		if player:HasCollectible(27) and player:HasCollectible(28) and player:HasCollectible(32) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then 
				player.Damage = ((player.Damage-40)*1.5)+40 
			else -- 아니면
				player.Damage = player.Damage * 1.5
			end
		end
		if player:HasCollectible(symbolp_item) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.2)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.2 -- 그냥 1.3배
			end
		end
		if player:HasCollectible(farsp_item) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.2)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.2 -- 그냥 1.3배
			end
		end
		if player:HasCollectible(rosettap_item) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.2)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.2 -- 그냥 1.3배
			end
		end
		if isPowerBondTimeOut == false then
			player.Damage = player.Damage * 4
		end
		if isLimiterRemovalTimeOut == false then
			player.Damage = player.Damage * 2
		end
		if shadowremove == true then
			player.Damage = player.Damage * 1.5
		end
		if player:HasCollectible(29) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.1)+40
			else -- 아니면
				player.Damage = player.Damage * 1.1
			end
		end
		if player:HasCollectible(30) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.1)+40
			else -- 아니면
				player.Damage = player.Damage * 1.1
			end
		end
		if player:HasCollectible(68) and not player:HasCollectible(114) then
			player.Damage = player.Damage * 1.5 -- 그냥 1.3배
		end
		if player:HasCollectible(118) and not player:HasCollectible(114) then
			player.Damage = player.Damage * 1.5 -- 그냥 1.3배
		end
		if player:HasCollectible(411) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.1)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.1 -- 그냥 1.3배
			end
		end
		if player:HasCollectible(442) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.3)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.3 -- 그냥 1.3배
			end
		end
		if player:HasCollectible(168) and player:HasCollectible(229) then
			player.Damage = player.Damage / 2
		end
		if player:HasCollectible(213) then
			if player:HasCollectible(149) and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(395) == false then
				player.Damage = ((player.Damage-40)*1.15)+40 -- 40 먼저 빼고 1.3를 곱해서 다시 40 더한다.
			else -- 아니면
				player.Damage = player.Damage * 1.15 -- 그냥 1.3배
			end
		end
	end
	if (cacheFlag == CacheFlag.CACHE_RANGE) then -- 아이템 획득 시 cacheFlag가 사거리면
		if player:HasCollectible(24) then -- 24를 획득했을 시
			player.TearHeight = player.TearHeight - 5.25 -- 사거리를 5.25 증가(마이너스가 될 수록 멀리)
		end
		if player:HasCollectible(237) then
			player.TearHeight = player.TearHeight - 13
		end
	end
	if (cacheFlag == CacheFlag.CACHE_SPEED) then -- 아이템 획득 시 cacheFlag가 스피드면
		if player:HasCollectible(24) then -- 24를 획득했을 시
			player.MoveSpeed = player.MoveSpeed + 2.0 -- 스피드를 0.6 증가
		end
		if player:HasCollectible(25) then -- 25를 획득했을 시
			player.MoveSpeed = player.MoveSpeed + (0.2 * player:GetCollectibleNum(25)) -- 0.2의 스피드를 25를 획득한 수 만큼 증가
		end
		if player:HasCollectible(82) then -- 82를 획득했을 시
			player.MoveSpeed = player.MoveSpeed + 0.3 -- 스피드를 0.3 증가
		end
		if player:HasCollectible(66) then 
			player.MoveSpeed = player.MoveSpeed + 2.0 
		end
		if isMegaBlastTimeOut == false then
			player.MoveSpeed = player.MoveSpeed + 2.0 
		end
		if spiceuse == true then
			player.MoveSpeed = player.MoveSpeed - (spiceused /10)
		end
	end
	if (cacheFlag == CacheFlag.CACHE_LUCK) then -- 아이템 획득 시 CacheFlag가 운이면
		if player:HasCollectible(23) then -- 23 획득했을 시
			player.Luck  = player.Luck + 4 -- 럭 3 증가
		end
		if player:HasCollectible(46) then -- 46 획득했을 시
			player.Luck  = player.Luck + 1 -- 럭 4 증가
		end
		if player:HasCollectible(449) then
			player.Luck  = player.Luck + 7
		end
		if player:HasCollectible(374) then
			player.Luck  = player.Luck - 3
		end
		if player:HasCollectible(355) then
			player.Luck = player.Luck + pearlrandom
		end
		if player:HasCollectible(339) then
			player.Luck  = 0
		end
		if player:HasCollectible(331) then
			player.Luck  = 0
		end
		if player:HasCollectible(221) then
			player.Luck  = 0
		end
		if player:HasCollectible(496) then
			player.Luck  = player.Luck - 3
		end
		if spiceuse == true then
			player.Luck = player.Luck - spiceused
		end
	end
	if (cacheFlag == CacheFlag.CACHE_TEARFLAG) then
		if player:HasCollectible(339) then -- 339 획득
			player.TearFlags = getFlag({38}, player.TearFlags); -- 38번 플래그를 줌
		end
		if player:HasCollectible(401) then -- 401 획득
			player.TearFlags = getFlag({36}, player.TearFlags); -- 36번 플래그를 줌
		end
		if player:HasCollectible(148) then 
			player.TearFlags = getFlag({48}, player.TearFlags); 
		end
		if haslumen == true then 
			player.TearFlags = getFlag({2}, player.TearFlags); -- 2번 플래그를 줌
		end
		if player:HasCollectible(428) then 
			player.TearFlags = getFlag({2,3,4,14,15,21}, player.TearFlags); 
		end
		if player:HasCollectible(529) then
			player.TearFlags = getFlag({2}, player.TearFlags);
		end
		if player:HasCollectible(237) then
			player.TearFlags = getFlag({20}, player.TearFlags);
		end
		if player:HasCollectible(114) then
			player.TearFlags = getFlag({3}, player.TearFlags);
		end
		if player:HasCollectible(34) then
			player.TearFlags = getFlag({2,51}, player.TearFlags);
		end
		if player:HasCollectible(27) and player:HasCollectible(28) and player:HasCollectible(32) then
			player.TearFlags = getFlag({6}, player.TearFlags);
		end
		if player:HasCollectible(213) then
			player.TearFlags = getFlag({2}, player.TearFlags);
		end
		if player:HasCollectible(3) then
			player.TearFlags = getFlag({2}, player.TearFlags);
		end
		if isMegaBlastTimeOut == false then
			player.TearFlags = getFlag({3}, player.TearFlags);
		end
	end
	if (cacheFlag == CacheFlag.CACHE_SHOTSPEED) then
		if player:HasCollectible(237) then
			player.ShotSpeed = player.ShotSpeed + 3
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(237) then
			player.MaxFireDelay = player.MaxFireDelay + 10
		end
		if player:HasCollectible(28) then
			player.MaxFireDelay = player.MaxFireDelay - 1
		end
	end
	if (cacheFlag == CacheFlag.CACHE_FLYING) then
		if player:HasCollectible(122) then
			player.CanFly = true
		end
	end
end

ChaosGreed:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, ChaosGreed.Item1)

function ChaosGreed:PlayerInit(player)
	hasMorphine = false

	if Game():GetFrameCount() < 5 then
		Isaac.SaveModData(ChaosGreed, "0,0,0")
		Isaac.DebugString("New Run");
		heldItem = 0
		heldItemCharge = 0
		storedItem = 0
		storedItemCharge = 0
		swapBuffer = 0
		useItemFrame = 0
		werryContinue = 0
		powerBondContinue = 0
		limiterRemovalContinue = 0
		covContinue = 0
		quickChaosContinue = 0
		megaContinue = 0
		isWerryTimeOut = true
		isPowerBondTimeOut = true
		isLimiterRemovalTimeOut = true
		isCovTimeOut = true
		isQuickChaosTimeOut = true
		isMegaBlastTimeOut = true
		isforcesuccess = 0
		isamplisuccess = 0
		shadowremove = false
		haslumen = false
		spiceused = 0
		spiceuse = false
		stopwatchContinue = 0
		isWatchTimeOut = true
		cipherContinue = 0
		cipheruse = false
		pearlrandom = math.random(0,3)
		eterbanji = 0
		errorTeleportStartedFrame = -1
		UGTeleportStartedFrame = -1
		roomiscleared = 0
		roomseedisold = 0
		ranscroll = 0
		soulshaveuse = false
		soulshaveContinue = 0
		hippoContinue = 0
		isHippoTimeOut = true
		timer:Init()
		--Game():Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TAROTCARD, player.Position + Vector(0, -1), Vector(0, 0), player, Card.CARD_HERMIT, player.InitSeed)
		--Game():Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TAROTCARD, player.Position + Vector(0, 1), Vector(0, 0), player, Card.CARD_STARS, player.InitSeed)
	end
	local saveData = Isaac.LoadModData(ChaosGreed)
	local a, b, c = saveData:match("([^,]+),([^,]+),([^,]+)")
	storedItem = tonumber(a)
	storedItemCharge = tonumber(b)
	batteryCharge = tonumber(c)
	if storedItem ~= 0 then
		storedItemSprite:ReplaceSpritesheet(0, config:GetCollectible(storedItem).GfxFileName)
		storedItemSprite:LoadGraphics()
		Isaac.DebugString("Graphics Loaded");
	end
	Isaac.DebugString("Backpack Loaded");
end

ChaosGreed:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, ChaosGreed.PlayerInit);

function ChaosGreed:Item2(currentPlayer) -- 패시브 설정용 함수

	local player = Isaac.GetPlayer(0) -- 플레이어 변수 설정
	local entities = Isaac.GetRoomEntities()
	
	if player:HasCollectible(280)==true and player:GetCollectibleNum(280)<3 then -- 280을 획득했고 3개 이하면(씨씨)
		player:AddCollectible(280,0,true) -- 3개를 얻을 때까지 반복해서 280 획득
	end
	if player:HasCollectible(511)==true and player:GetCollectibleNum(511)<3 then -- 511을 획득했고 3개 이하면(앵그리플라이)
		player:AddCollectible(511,0,true) -- 3개를 얻을 때까지 반복해서 511 획득
	end
	if player:HasCollectible(197)==true and player:GetCollectibleNum(197)<6 then -- 197을 획득했고 3개 이하면(쥬스)
		player:AddCollectible(197,0,true) -- 3개를 얻을 때까지 반복해서 197 획득
	end
	if player:HasCollectible(193)==true and player:GetCollectibleNum(193)<10 then -- 193을 획득했고 5개 이하면(미트)
		player:AddCollectible(193,0,true) -- 5개를 얻을 때까지 반복해서 193 획득
	end
	if player:HasCollectible(138)==true and player:GetCollectibleNum(138)<5 then -- 138을 획득했고 5개 이하면(스티그마)
		player:AddCollectible(138,0,true) -- 5개를 얻을 때까지 반복해서 138 획득
	end
	if player:HasCollectible(493)==true and player:GetCollectibleNum(208)<10 then -- 493을 획득했고 208이 10개 이하면(아드레날린/챔벨)
		player:AddCollectible(208,0,true) -- 10개를 얻을 때까지 반복해서 208 획득
	end
	if player:HasCollectible(417)==true and player:GetCollectibleNum(417)<2 then -- 417을 획득했고 2개 이하면(서큐)
		player:AddCollectible(417,0,true) -- 2개를 얻을 때까지 반복해서 417 획득
	end
	if player:HasCollectible(317)==true and player:GetCollectibleNum(48)<1 then -- 317을 획득했고 48이 1개 이하면(섬창/큐피드)
		player:AddCollectible(48,0,true) -- 1개를 얻을 때까지 반복해서 48 획득
	end
	if player:HasCollectible(201)==true and player:GetCollectibleNum(201)<5 then -- 201을 획득했고 5개 이하면(철괴)
		player:AddCollectible(201,0,true) -- 5개를 얻을 때까지 반복해서 201 획득
	end
	if player:HasCollectible(207)==true and player:GetCollectibleNum(207)<4 then -- 207을 획득했고 4개 이하면(밴드)
		player:AddCollectible(207,0,true) -- 4개를 얻을 때까지 반복해서 415 획득
	end
	if player:HasCollectible(73)==true and player:GetCollectibleNum(73)<4 then -- 73을 획득했고 4개 이하면(미트)
		player:AddCollectible(73,0,true) -- 4개를 얻을 때까지 반복해서 73 획득
	end
	if player:HasCollectible(155)==true and player:GetCollectibleNum(155)<3 then -- 155을 획득했고 3개 이하면(피퍼)
		player:AddCollectible(155,0,true) -- 3개를 얻을 때까지 반복해서 155 획득
	end
	if player:HasCollectible(405)==true and player:GetCollectibleNum(405)<3 then -- 405을 획득했고 3개 이하면(기가바이트)
		player:AddCollectible(405,0,true) -- 3개를 얻을 때까지 반복해서 405 획득
	end
	if player:HasCollectible(238)==true and player:HasCollectible(239)==true then -- 238과 239를 획득했다면(키피스 1,2)
		if player:HasCollectible(499)==false then --499가 없다면
			player:AddCollectible(499,0,true) -- 499 획득
			player:RemoveCollectible(238)
			player:RemoveCollectible(239)
		end
	end
	if player:HasCollectible(179)==true and player:HasCollectible(82)==true then
		if player:HasCollectible(402)==false then
			player:AddCollectible(402,0,true)
		end
	end
	if player:HasCollectible(29)==true and player:GetCollectibleNum(381)<2 then 
		player:AddCollectible(381,0,true) 
	end
	if player:HasCollectible(30)==true and player:HasCollectible(387)==false then 
		player:AddCollectible(387,0,true) 
	end
	if player:HasCollectible(170)==true and player:GetCollectibleNum(170)<2 then 
		player:AddCollectible(170,0,true) 
	end
	if player:HasCollectible(318)==true and player:GetCollectibleNum(318)<2 then 
		player:AddCollectible(318,0,true)
	end
	if player:HasCollectible(165)==true and player:GetCollectibleNum(165)<2 then 
		player:AddCollectible(165,0,true)
	end
	if player:HasCollectible(275)==true and player:GetCollectibleNum(275)<3 then 
		player:AddCollectible(275,0,true)
	end
	if player:HasCollectible(508)==true and player:GetCollectibleNum(508)<3 then 
		player:AddCollectible(508,0,true)
	end
	if player:HasCollectible(50)==true and player:GetCollectibleNum(50)<2 then 
		player:AddCollectible(50,0,true)
	end
	if player:HasCollectible(7)==true and player:HasCollectible(462)==false then 
		player:AddCollectible(462,0,true) 
	end
	if player:HasCollectible(79)==true and player:GetCollectibleNum(79)<10 then 
		player:AddCollectible(79,0,true)
	end
	if player:HasCollectible(80)==true and player:GetCollectibleNum(80)<10 then 
		player:AddCollectible(80,0,true)
	end
	if player:HasCollectible(399)==true and player:GetCollectibleNum(399)<5 then 
		player:AddCollectible(399,0,true)
	end
	if player:HasCollectible(463)==true and player:GetCollectibleNum(463)<3 then 
		player:AddCollectible(463,0,true)
	end
	if player:HasCollectible(345)==true and player:GetCollectibleNum(345)<2 then 
		player:AddCollectible(345,0,true)
	end
	if player:HasCollectible(279)==true and player:GetCollectibleNum(279)<3 then 
		player:AddCollectible(279,0,true)
	end
	if player:HasCollectible(359)==true and player:GetCollectibleNum(359)<2 then 
		player:AddCollectible(359,0,true)
	end
	if player:HasCollectible(symbolp_item) and player:HasCollectible(farsp_item) and player:HasCollectible(rosettap_item) and player:HasCollectible(182) == false then
		player:RemoveCollectible(symbolp_item)
		player:RemoveCollectible(farsp_item)
		player:RemoveCollectible(rosettap_item)
		player:AddCollectible(182,0,true)
	end
	if player:HasCollectible(51)==true and player:GetCollectibleNum(51)<3 then 
		player:AddCollectible(51,0,true)
	end
	if player:HasCollectible(411) and player:HasCollectible(51) then
		player:AddCollectible(157,0,true)
		player:RemoveCollectible(411)
		player:RemoveCollectible(51)
		player:RemoveCollectible(51)
		player:RemoveCollectible(51)
	end
	if player:HasCollectible(528)==true and player:GetCollectibleNum(528)<3 then 
		player:AddCollectible(528,0,true)
	end
	if player:HasCollectible(526)==true and player:GetCollectibleNum(526)<2 then 
		player:AddCollectible(526,0,true)
	end
	if player:HasCollectible(241)==true and player:HasCollectible(245)==false then
		player:AddCollectible(245,0,true)
	end
	if player:HasCollectible(445)==true and player:GetCollectibleNum(445)<5 then 
		player:AddCollectible(445,0,true)
	end
	if player:HasCollectible(31)==true then
		haslumen = true
		player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
		player:EvaluateItems()
		if math.random(1,2)==1 then
			player:AddCollectible(415,0,true)
		else
			player:AddCollectible(442,0,true)
		end
		player:RemoveCollectible(31)
	end
	if player:HasCollectible(172)==true and player:GetCollectibleNum(172)<3 then 
		player:AddCollectible(172,0,true)
	end
	if player:HasCollectible(29) and player:HasCollectible(30) and haslumen == true then
		if player:GetCollectibleNum(417)<8 then
			player:AddCollectible(417,0,true)
		end
	end
	if player:HasCollectible(119)==true then -- 119를 획득하면(앱솔루트 구피)
		if player:HasCollectible(134)==false then -- 134를 획득하지 않았을 때
			player:AddCollectible(134,0,true) -- 134 획득
		end
		if player:HasCollectible(187)==false then -- 이하 반복
			player:AddCollectible(187,0,true)
		end
		if player:HasCollectible(212)==false then
			player:AddCollectible(212,0,true)
		end
	end
	if player:HasCollectible(75)==true then -- 앱솔루트 마약
		if player:HasCollectible(70)==false then
			player:AddCollectible(70,0,true)
		end
		if player:HasCollectible(13)==false then
			player:AddCollectible(13,0,true)
		end
		if player:HasCollectible(143)==false then
			player:AddCollectible(143,0,true)
		end
	end
	if player:HasCollectible(253)==true then -- 앱솔루트 종양
		if player:HasCollectible(322)==false then
			player:AddCollectible(322,0,true)
		end
		if player:HasCollectible(268)==false then
			player:AddCollectible(268,0,true)
		end
		if player:HasCollectible(167)==false then
			player:AddCollectible(167,0,true)
		end
	end
	if player:HasCollectible(329)==true then -- 앱솔루트 유황
		if player:HasCollectible(118)==false then
			player:AddCollectible(118,0,true)
		end
	end
	if player:HasCollectible(52)==true then -- 폭셋
		if player:HasCollectible(220)==false then
			player:AddCollectible(220,0,true)
		end
	end
	if player:HasCollectible(255)==true then -- 정마반
		if player:HasCollectible(260)==false then
			player:AddCollectible(260,0,true)
		end
	end
	if player:HasCollectible(9)==true then -- 앱솔루트 파리셋
		if player:HasCollectible(264)==false then
			player:AddCollectible(264,0,true)
		end
		if player:HasCollectible(492)==false then
			player:AddCollectible(492,0,true)
		end
		if player:HasCollectible(chiggers_item)==false then
			player:AddCollectible(chiggers_item,0,true)
		end
	end
	if player:HasCollectible(173)==true then -- 앱솔루트 세라핌
		if player:HasCollectible(156)==false then
			player:AddCollectible(156,0,true)
		end
		if player:HasCollectible(72)==false then
			player:AddCollectible(72,0,true)
		end
		if player:HasCollectible(101)==false then
			player:AddCollectible(101,0,true)
		end
		if player:HasCollectible(390)==false then
			player:AddCollectible(390,0,true)
		end
	end
	if player:HasCollectible(346)==true then -- 앱솔루트 레비아탄
		if player:HasCollectible(79)==false then
			player:AddCollectible(79,0,true)
		end
		if player:HasCollectible(80)==false then
			player:AddCollectible(80,0,true)
		end
		if player:HasCollectible(159)==false then
			player:AddCollectible(159,0,true)
		end
	end
	if player:HasCollectible(129)==true then -- 앱솔루트 그혈
		if player:HasCollectible(118)==false then
			player:AddCollectible(118,0,true)
		end
		if player:HasCollectible(222)==false then
			player:AddCollectible(222,0,true)
		end
		if player:GetCollectibleNum(381)<3 then
			player:AddCollectible(381,0,true)
		end
	end
	if player:HasCollectible(223) then
		if player:HasCollectible(106)==false then
			player:AddCollectible(106,0,true)
		end
		if player:HasCollectible(125)==false then
			player:AddCollectible(125,0,true)
		end
		if player:HasCollectible(140)==false then
			player:AddCollectible(140,0,true)
		end
		if player:HasCollectible(220)==false then
			player:AddCollectible(220,0,true)
		end
		if player:HasCollectible(256)==false then
			player:AddCollectible(256,0,true)
		end
		if player:HasCollectible(353)==false then
			player:AddCollectible(353,0,true)
		end
		if player:HasCollectible(367)==false then
			player:AddCollectible(367,0,true)
		end
		if player:HasCollectible(517)==false then
			player:AddCollectible(517,0,true)
		end
	end
	if player:HasCollectible(456) then -- 만약 클리너 소지 시
		if player:HasCollectible(52) then -- 닥터 소지 시
			player:RemoveCollectible(52) -- 닥터 제거
		end
		if player:HasCollectible(68) then -- 테크 소지 시
			player:RemoveCollectible(68) -- 테크 제거
			player:RemoveCollectible(68)
		end
		if player:HasCollectible(114) then -- 칼 소지 시
			player:RemoveCollectible(114) -- 칼 제거
		end
		if player:HasCollectible(118) then -- 혈사 소지 시
			player:RemoveCollectible(118) -- 혈사 제거
			player:RemoveCollectible(118)
		end
		if player:HasCollectible(129) then -- 그혈 소지 시
			player:RemoveCollectible(129) -- 그혈 제거
		end
		if player:HasCollectible(149) then -- 구토 소지 시
			player:RemoveCollectible(149) -- 구토 제거
		end
		if player:HasCollectible(152) then -- 테크2 소지 시
			player:RemoveCollectible(152) -- 테크2 제거
		end
		if player:HasCollectible(168) then -- 에픽 소지 시
			player:RemoveCollectible(168) -- 에픽 제거
		end
		if player:HasCollectible(233) then -- 플래닛 소지 시
			player:RemoveCollectible(233) -- 플래닛 제거
		end
		if player:HasCollectible(329) then -- 루도비코 소지 시
			player:RemoveCollectible(329) -- 루도비코 제거
		end
		if player:HasCollectible(395) then -- 테크엑스 소지 시
			player:RemoveCollectible(395) -- 테크엑스 제거
		end
		if player:HasCollectible(52) == false and player:HasCollectible(68) == false and player:HasCollectible(114) == false and player:HasCollectible(118) == false and player:HasCollectible(129) == false and player:HasCollectible(149) == false and player:HasCollectible(152) == false and player:HasCollectible(168) == false and player:HasCollectible(233) == false and player:HasCollectible(329) == false and player:HasCollectible(395) == false then -- 공격 변화 아이템이 없는 경우
			player:RemoveCollectible(456) -- 클리너 제거
		end
	end
	if player:HasCollectible(115) then -- 만약 히오스 소지 시
		if player:HasCollectible(22) then -- 샛별 소지 시
			player:RemoveCollectible(22) -- 샛별 제거
		end
		if player:HasCollectible(23) then -- 향기 소지 시
			player:RemoveCollectible(23) -- 향기 제거
		end
		if player:HasCollectible(24) then -- 물소리 소지 시
			player:RemoveCollectible(24) -- 물소리 제거
		end
		if player:HasCollectible(21) then -- 삼신기 소지 시
			player:RemoveCollectible(21) -- 삼신기 제거
		end
		if player:HasCollectible(26) then -- 삼신기 소지 시
			player:RemoveCollectible(26) -- 삼신기 제거
		end
		if player:HasCollectible(54) then -- 삼신기 소지 시
			player:RemoveCollectible(54) -- 삼신기 제거
		end
		if player:HasCollectible(81) then -- 구피 소지 시
			player:RemoveCollectible(81) -- 구피 제거
		end
		if player:HasCollectible(133) then -- 구피 소지 시
			player:RemoveCollectible(133) -- 구피 제거
		end
		if player:HasCollectible(134) then -- 구피 소지 시
			player:RemoveCollectible(134) -- 구피 제거
		end
		if player:HasCollectible(212) then -- 구피 소지 시
			player:RemoveCollectible(212) -- 구피 제거
		end
		if player:HasCollectible(29) then -- 솔리움 폰스 소지 시
			player:RemoveCollectible(29) --솔리움 폰스 제거
		end
		if player:HasCollectible(30) then -- 테네브레 루스 소지 시
			player:RemoveCollectible(30) -- 테네브레 루스 제거
		end
		if player:HasCollectible(31) then -- 루멘 바실리움 소지 시
			player:RemoveCollectible(31) -- 루멘 바실리움 제거
		end
		if player:HasCollectible(241) then -- 정마팔 소지 시
			player:RemoveCollectible(241) -- 정마팔 제거
		end
		if player:HasCollectible(249) then -- 정마목 소지 시
			player:RemoveCollectible(249) -- 정마목 제거
		end
		if player:HasCollectible(255) then -- 정마반 소지 시
			player:RemoveCollectible(255) -- 정마반 제거
		end
		if player:HasCollectible(238) then -- 키피스 소지 시
			player:RemoveCollectible(238) -- 키피스 제거
		end
		if player:HasCollectible(239) then -- 키피스 소지 시
			player:RemoveCollectible(239) -- 키피스 제거
		end
		if player:HasCollectible(82) then -- 군주 소지 시
			player:RemoveCollectible(82) -- 군주 제거
		end
		if player:HasCollectible(179) then -- 페이트 소지 시
			player:RemoveCollectible(179) -- 페이트 제거
		end
		if player:HasCollectible(51) then -- 펜타 소지 시
			player:RemoveCollectible(51) -- 펜타 제거
		end
		if player:HasCollectible(411) then -- 구레이저 소지 시
			player:RemoveCollectible(411) -- 구레이저 제거
		end
		if player:HasCollectible(27) then -- 얼공 소지 시
			player:RemoveCollectible(27) -- 얼공 제거
		end
		if player:HasCollectible(28) then -- 얼공 소지 시
			player:RemoveCollectible(28) -- 얼공 제거
		end
		if player:HasCollectible(32) then -- 얼공 소지 시
			player:RemoveCollectible(32) -- 얼공 제거
		end
		if player:HasCollectible(farsp_item) then 
			player:RemoveCollectible(farsp_item) 
		end
		if player:HasCollectible(rosettap_item) then 
			player:RemoveCollectible(rosettap_item) 
		end
		if player:HasCollectible(symbolp_item) then 
			player:RemoveCollectible(symbolp_item) 
		end
		if player:HasCollectible(22) == false and player:HasCollectible(23) == false and player:HasCollectible(24) == false and player:HasCollectible(21) == false and player:HasCollectible(26) == false and player:HasCollectible(54) == false and player:HasCollectible(81) == false and player:HasCollectible(133) == false and player:HasCollectible(134) == false and player:HasCollectible(212) == false and player:HasCollectible(29) == false and player:HasCollectible(30) == false and player:HasCollectible(31) == false and player:HasCollectible(241) == false and player:HasCollectible(249) == false and player:HasCollectible(255) == false and player:HasCollectible(238) == false and player:HasCollectible(239) == false and player:HasCollectible(82) == false and player:HasCollectible(179) == false and player:HasCollectible(51) == false and player:HasCollectible(411) == false then
			player:RemoveCollectible(115) -- 히오스 제거
		end
	end
	if player:GetPlayerType() == 5 and player:HasCollectible(126) then --만약 플레이어가 이브(5)이고 만약 126(면도) 소지 시라면
		player:AddCollectible(485,24,true)
	end
	if player:GetPlayerType() == 5 and player:HasCollectible(356) then 
		player:RemoveCollectible(356)
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(349) then 
		player:AddCollectible(521,30,true)
	end
	if player:GetPlayerType() == 10 and player:HasCollectible(482) then
		player:RemoveCollectible(482)
	end
	if player:GetPlayerType() == 10 and player:HasCollectible(332) then
		player:RemoveCollectible(332)
	end
	if player:GetPlayerType() == 10 and player:HasCollectible(311) then
		player:RemoveCollectible(311)
		shadowremove = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if player:GetPlayerType() == 10 and player:HasCollectible(161) then
		player:RemoveCollectible(161)
	end
	if player:GetPlayerType() == 10 and player:GetTrinket(28) then
		player:TryRemoveTrinket(28)
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(482) then
		player:RemoveCollectible(482)
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(332) then
		player:RemoveCollectible(332)
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(311) then
		player:RemoveCollectible(311)
		shadowremove = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(161) then
		player:RemoveCollectible(161)
	end
	if player:GetPlayerType() == 14 and player:GetTrinket(23) then
		player:TryRemoveTrinket(23)
	end
	if player:GetPlayerType() == 14 and player:GetTrinket(28) then
		player:TryRemoveTrinket(28)
	end
	if player:GetPlayerType() == 14 and player:HasCollectible(227) then
		player:RemoveCollectible(227)
	end
	if player:GetPlayerType() == 14 and player:GetTrinket(1) then
		player:TryRemoveTrinket(1)
	end
	if player:GetTrinket(51) then -- 동일
		player:TryRemoveTrinket(51)
	end
	if player:GetTrinket(50) then
		player:TryRemoveTrinket(50)
	end
	if player:GetTrinket(49) then 
		player:TryRemoveTrinket(49)
	end
	if player:GetTrinket(112) then 
		player:TryRemoveTrinket(112)
	end
	if player:GetTrinket(82) then 
		player:TryRemoveTrinket(82)
	end

	if isWerryTimeOut == false and werryContinue <= Game().TimeCounter then -- 지속 시간이 아니고 아직 처리하지 않았다면
		isWerryTimeOut = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if isPowerBondTimeOut == false and powerBondContinue <= Game().TimeCounter then
		isPowerBondTimeOut = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if isLimiterRemovalTimeOut == false and limiterRemovalContinue <= Game().TimeCounter then
		isLimiterRemovalTimeOut = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if isCovTimeOut == false and covContinue <= Game().TimeCounter then
		isCovTimeOut = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if isQuickChaosTimeOut == false and quickChaosContinue <= Game().TimeCounter then
		isQuickChaosTimeOut = true
		player:RemoveCollectible(402) -- 카오스 삭제
		player:RemoveCollectible(402)
	end
	if isMegaBlastTimeOut == false and megaContinue <= Game().TimeCounter then
		isMegaBlastTimeOut = true
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
		player:AddCacheFlags(CacheFlag.CACHE_SPEED)
		player:EvaluateItems()
	end
	if isWatchTimeOut == false and stopwatchContinue <= Game().TimeCounter then
		isWatchTimeOut = true
	end
	if stopwatchContinue == Game().TimeCounter then
		player:AddCollectible(232,0,true)
	end
	if cipheruse == true and cipherContinue <= Game().TimeCounter then
		cipheruse = false
		Isaac.Spawn(5, 100,specialitem[math.random(1,31)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
	end
	if soulshaveuse == true and soulshaveContinue <= Game().TimeCounter then
		soulshaveuse = false
		local i = math.random(1,3)
		if i == 1 then
			Isaac.Spawn(5, 100, 64, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 2 then
			Isaac.Spawn(5, 100, 203, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		else
			Isaac.Spawn(5, 350, 52, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		end
	end
	if isHippoTimeOut == false and hippoContinue <= Game().TimeCounter then
		isHippoTimeOut = true
		player:RemoveCollectible(114)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
	end
	if errorTeleportStartedFrame ~= -1 then
		if errorTeleportStartedFrame + 19 <= Game():GetFrameCount() then
			Game():ChangeRoom(Game():GetLevel():QueryRoomTypeIndex(RoomType.ROOM_ERROR, true, RNG()))
			errorTeleportStartedFrame = -1
			player:AnimateTeleport(false)
		end
	end
	if UGTeleportStartedFrame ~= -1 then
		if UGTeleportStartedFrame + 19 <= Game():GetFrameCount() then
			Isaac.ExecuteCommand("stage 7")
			UGTeleportStartedFrame = -1
			player:AnimateTeleport(false)
		end
	end

	if player:HasCollectible(29) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 150
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddCharmed(1)
				end
			end
		end
	end

	if player:HasCollectible(30) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 150
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddSlowing(EntityRef(player),1,20,Color(0.5, 0.5, 0.5, 1, 0, 0, 0))
				end
			end
		end
	end

	if player:HasCollectible(51) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 150
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddFear(EntityRef(player),1)
				end
			end
		end
	end

	if player:HasCollectible(103) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 150
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddPoison(EntityRef(player),2,1)
				end
			end
		end
	end

	if player:HasCollectible(27) and player:HasCollectible(28) and player:HasCollectible(32) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 300
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddFreeze(EntityRef(player),1)
				end
			end
		end
	elseif (player:HasCollectible(27) and player:HasCollectible(28)) or (player:HasCollectible(28) and player:HasCollectible(32)) or (player:HasCollectible(27) and player:HasCollectible(32)) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 150
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddFreeze(EntityRef(player),1)
				end
			end
		end
	elseif player:HasCollectible(27) or player:HasCollectible(28) or player:HasCollectible(32) then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 75
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddFreeze(EntityRef(player),1)
				end
			end
		end
	end

	if isWatchTimeOut == false then
		for i = 1, #entities do
			if entities[i]:IsVulnerableEnemy() then
				local fearrange = 300
				if player.Position.X-fearrange <= entities[i].Position.X and
				player.Position.X+fearrange >= entities[i].Position.X and
				-(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y <= entities[i].Position.Y and
				(fearrange^2-(entities[i].Position.X-player.Position.X)^2)^0.5+player.Position.Y>= entities[i].Position.Y  then
					entities[i]:AddSlowing(EntityRef(player),1,20,Color(0.5, 0.5, 0.5, 1, 0, 0, 0))
				end
			end
		end
	end

	-- 타이머 갱신
	timer:Renew()

	--[[if player:HasCollectible(105) then
		if (Game():GetLevel():GetAngelRoomChance() < 0.05) then
			Game():GetLevel():AddAngelRoomChance(0.05)
		end
	end]]

	-- 갓모드 패시브 아이템
	if hasMorphine then
        player:AddHearts(-24)
        player:AddHearts(2)
    end

    if player:HasCollectible(backpack_item) then
		if hasBackpack == false then
			player:AddNullCostume(Isaac.GetCostumeIdByPath("gfx/characters/costumes/backpack_costume.anm2"))
			hasBackpack = true
			Isaac.DebugString("Adding Costume");
		end

		-- Picks up an active item when doesn't currently have one
		if heldItem == 0 and player:GetActiveItem() ~= 0 then
			heldItem = player:GetActiveItem()
			heldItemCharge = player:GetActiveCharge()
		end
		-- Picks up an active item when is currently holding one, no stored item
		if heldItem ~= 0 and heldItem ~= player:GetActiveItem() and storedItem == 0 and Game():GetFrameCount() > useItemFrame then
			-- 들고 있던 아이템이 사라졌다면?
			if player:GetActiveItem() == 0 and Game():GetFrameCount() <= useItemFrame + 20 then
				heldItem = 0
				heldItemCharge = 0
			end
			storedItem = heldItem
			storedItemCharge = heldItemCharge
			storedItemSprite:ReplaceSpritesheet(0, config:GetCollectible(storedItem).GfxFileName)
			storedItemSprite:LoadGraphics()
			heldItem = player:GetActiveItem()
			heldItemCharge = player:GetActiveCharge()
			-- Remove pedestal
			for i, entity in pairs(Isaac.GetRoomEntities()) do
				if entity.Type == EntityType.ENTITY_PICKUP and entity.Variant == PickupVariant.PICKUP_COLLECTIBLE then
					if entity.SubType == storedItem then
						entity:Remove()
					end
				end
			end
		end
		-- Picks up an active item when is currently holding two items
		if heldItem ~= 0 and heldItem ~= player:GetActiveItem() and storedItem ~= 0 then
			heldItem = player:GetActiveItem()
			heldItemCharge = player:GetActiveCharge()
			player:DischargeActiveItem()
			player:SetActiveCharge(heldItemCharge + batteryCharge)
			Isaac.DebugString(player:GetActiveSubCharge());
		end
		-- Presses the swap key and has two items
		if (Input.IsButtonPressed(swapItemKey, player.ControllerIndex) or (controllerMode and Input.IsActionTriggered(ButtonAction.ACTION_DROP, player.ControllerIndex))) and storedItem ~= 0 and Game():GetFrameCount() > swapBuffer then
			swapBuffer = Game():GetFrameCount() + 10
			heldItem = player:GetActiveItem()
			heldItemCharge = player:GetActiveCharge()
			-- Update battery data
			if player:GetActiveCharge() ~= 0 then
				if player:GetBatteryCharge() == heldItemCharge then
					if batteryCharge < player:GetBatteryCharge() then
						batteryCharge = player:GetBatteryCharge()
					end
				else
					batteryCharge = player:GetBatteryCharge()
				end
			end
			-- Swap items
			player:AddCollectible(storedItem, 0, false)
			player:RemoveCollectible(heldItem)
			--player:DischargeActiveItem()
			player:SetActiveCharge(storedItemCharge + batteryCharge)
			storedItem = heldItem
			storedItemCharge = heldItemCharge
			if storedItem ~= 0 then
				storedItemSprite:ReplaceSpritesheet(0, config:GetCollectible(storedItem).GfxFileName)
				storedItemSprite:LoadGraphics()
			end
		end
	end

	-- Save data
	local saveData = storedItem ..",".. storedItemCharge ..",".. batteryCharge
	Isaac.SaveModData(ChaosGreed, saveData)
end

ChaosGreed:AddCallback(ModCallbacks.MC_POST_UPDATE, ChaosGreed.Item2, EntityType.ENTITY_PLAYER)

function ChaosGreed:useItem(collectible, rng)
	local player = Isaac.GetPlayer(0)
	
    useItemFrame = Game():GetFrameCount() + 10

	if collectible == werry_item then -- Werry 사용시
		if werryContinue < Game().TimeCounter then -- 지속 시간이 아님
			local continueTime = 120 * 30

			werryContinue = Game().TimeCounter + continueTime -- 지속 시간 60초 뒤 (30은 단위 초로 변환)
			isWerryTimeOut = false

			timer:Insert(werry_item, continueTime, 1, 0, 0)

			player:RemoveCollectible(werry_item)
		end
		return true
	elseif collectible == powerbond_item then -- Power Bond 사용시
		if powerBondContinue < Game().TimeCounter then -- 지속 시간이 아님
			local continueTime = 30 * 30

			powerBondContinue = Game().TimeCounter + continueTime -- 지속 시간 30초 뒤 (30은 단위 초로 변환)
			isPowerBondTimeOut = false

			timer:Insert(powerbond_item, continueTime, 1, 0.005, 0)

			player:RemoveCollectible(powerbond_item)
		end
		return true
	elseif collectible == limiterremoval_item then -- Limiter Removal 사용시
		if limiterRemovalContinue < Game().TimeCounter then -- 지속 시간이 아님
			local continueTime = 45 * 30

			limiterRemovalContinue = Game().TimeCounter + continueTime -- 지속 시간 30초 뒤 (30은 단위 초로 변환)
			isLimiterRemovalTimeOut = false

			timer:Insert(limiterremoval_item, continueTime, 1, 1, 0)

			player:RemoveCollectible(limiterremoval_item)
		end
		return true
	elseif collectible == restore_item then
		Isaac.Spawn(6, 10, 0, player.Position + Vector(-50, -50), Vector(0, 0), player) -- 리스톡 소환
		Isaac.Spawn(6, 10, 0, player.Position + Vector(50, -50), Vector(0, 0), player)
		player:RemoveCollectible(restore_item)
		return true
	elseif collectible == chaos_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:AddCard(Card.CARD_CHAOS)
		player:RemoveCollectible(chaos_item)
		return true
	elseif collectible == 421 then
		player:RemoveCollectible(421)
		player:AnimateTeleport(true)
		errorTeleportStartedFrame = Game():GetFrameCount()
		return false
	elseif collectible == cov_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		if (Game():GetLevel():GetAngelRoomChance() < 1) then
			Game():GetLevel():AddAngelRoomChance(1);
		end
		player:AddCard(Card.CARD_JOKER)
		if covContinue < Game().TimeCounter then -- 지속 시간이 아님
			local continueTime = 30 * 30

			covContinue = Game().TimeCounter + continueTime -- 지속 시간 30초 뒤 (30은 단위 초로 변환)
			isCovTimeOut = false

			timer:Insert(cov_item, continueTime, 0.005, 1, 0)
		end
		player:RemoveCollectible(cov_item)
		return true
	elseif collectible == gamble_item then
		local rangamble = math.random(1,100)
		if rangamble <= 80 then
			player:AddCoins(30)
		elseif rangamble <= 95 then
			player:Die()
		else
			player:AddCoins(99)
		end
		player:RemoveCollectible(gamble_item)
		return true
	elseif collectible == stopwatch_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		if stopwatchContinue < Game().TimeCounter then
			local continueTime = 300 * 30

			stopwatchContinue = Game().TimeCounter + continueTime
			isWatchTimeOut = false

			timer:Insert(stopwatch_item, continueTime, 0, 1, 1)
		end
		player:RemoveCollectible(stopwatch_item)
		return true
	elseif collectible == symbol_item then
		local ransymbol = math.random(1,1000)
		if player.Luck<0 then
			if ransymbol <= 5 then
				player:RemoveCollectible(symbol_item)
				player:AddCollectible(symbolp_item,0,true)
			end
		else
			if ransymbol <= 5 + 10 * (math.floor(player.Luck)) then
				player:RemoveCollectible(symbol_item)
				player:AddCollectible(symbolp_item,0,true)
			end
		end
		return true
	elseif collectible == fars_item then
		local ranfars = math.random(1,1000)
		if player.Luck<0 then
			if ranfars <= 5 then
				player:RemoveCollectible(fars_item)
				player:AddCollectible(farsp_item,0,true)
			end
		else
			if ranfars <= 5 + 10 * (math.floor(player.Luck)) then
				player:RemoveCollectible(fars_item)
				player:AddCollectible(farsp_item,0,true)
			end
		end
		return true
	elseif collectible == rosetta_item then
		local ranrosetta = math.random(1,1000)
		if player.Luck<0 then
			if ranrosetta <= 5 then
				player:RemoveCollectible(rosetta_item)
				player:AddCollectible(rosettap_item,0,true)
			end
		else
			if ranrosetta <= 5 + 10 * (math.floor(player.Luck)) then
				player:RemoveCollectible(rosetta_item)
				player:AddCollectible(rosettap_item,0,true)
			end
		end
		return true
	--[[elseif collectible == infestedhead_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		for i=1,math.random(6,10) do
			Isaac.Spawn(EntityType.ENTITY_FAMILIAR, FamiliarVariant.BLUE_FLY, 2, player.Position, Vector(0, 0), player)
		end
		return true]]
	elseif collectible == quickchaos_item then
		if quickChaosContinue < Game().TimeCounter then -- 지속 시간이 아님
			local continueTime = 60 * 30

			quickChaosContinue = Game().TimeCounter + continueTime -- 지속 시간 30초 뒤 (30은 단위 초로 변환)
			isQuickChaosTimeOut = false

			timer:Insert(quickchaos_item, continueTime, 0, 1, 0)

			for i=1,5 do
				Isaac.Spawn(5, 20, 3, Isaac.GetFreeNearPosition(player.Position, 0), Vector(0,0), player)
			end
			player:RemoveCollectible(quickchaos_item)
			player:AddCollectible(402,0,true)
		end
		return true
	elseif collectible == skipforce_item then
		player:RemoveCollectible(skipforce_item)
		player:AnimateTeleport(true)
		UGTeleportStartedFrame = Game():GetFrameCount()
		return false
	elseif collectible == deathdoubleforce_item then
		player:RemoveCollectible(deathdoubleforce_item)
		Game():AddDevilRoomDeal()
		Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TAROTCARD, Card.CARD_JOKER, player.Position, Vector(math.random(-5,5),math.random(-5,5)), player)
		for i=1,8 do
			Isaac.Spawn(5, 360, 0, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0,0), player)
		end
		return true
	elseif collectible == 441 then
		if megaContinue < Game().TimeCounter then
			local continueTime = 15 * 30

			megaContinue = Game().TimeCounter + continueTime
			isMegaBlastTimeOut = false

			timer:Insert(441, continueTime, 0, 1, 0.005)
		end
		player:RemoveCollectible(441)
		return true
	elseif collectible == spice_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(spice_item)
		Isaac.Spawn(5, 100,curseroom[math.random(1,23)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		spiceused = spiceused * 2 + 1
		spiceuse = true
		player:AddCoins(-5*spiceused)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:AddCacheFlags(CacheFlag.CACHE_SPEED)
		player:AddCacheFlags(CacheFlag.CACHE_LUCK)
		player:EvaluateItems()
	elseif collectible == cipher_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(cipher_item)

		local continueTime = 150 * 30

		cipherContinue = Game().TimeCounter + continueTime
		cipheruse = true

		timer:Insert(cipher_item, continueTime, 0, 0.005, 1)
	elseif collectible == astral_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(astral_item)
		local j = math.random(1,100)
		if j <= 80 then
			for i=1,2 do
				Isaac.Spawn(5, 100,curseroom[math.random(1,23)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
			end
		elseif j <= 95 then
			for i=1,3 do
				Isaac.Spawn(5, 100,curseroom[math.random(1,23)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
			end
		else 
			for i=1,4 do
				Isaac.Spawn(5, 100,curseroom[math.random(1,23)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
			end
		end
		return true
	elseif collectible == raptor_item then
		player:RemoveCollectible(raptor_item)
		local i = math.random(1,6)
		if i == 1 then
			Isaac.Spawn(5, 100, quickchaos_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 2 then
			Isaac.Spawn(5, 100, skipforce_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 3 then
			Isaac.Spawn(5, 100, deathdoubleforce_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 4 then
			Isaac.Spawn(5, 100, astral_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 5 then
			Isaac.Spawn(5, 100, cipher_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		else
			Isaac.Spawn(5, 100, soulshave_item, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		end
	elseif collectible == eter_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(eter_item)
		eterbanji = eterbanji + 2
		Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TAROTCARD, Card.CARD_CREDIT, player.Position, Vector(math.random(-5,5),math.random(-5,5)), player)
		return true
	elseif collectible == mono_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(mono_item)
		local i = math.random(1,3)
		if i == 1 then
			Isaac.Spawn(5, 100, 29, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		elseif i == 2 then
			Isaac.Spawn(5, 100, 30, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		else
			Isaac.Spawn(5, 100, 31, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
		end
		return true
	elseif collectible == scroll_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(scroll_item)
		ranscroll = ranscroll + math.random(-20,20)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
		return true
	elseif collectible == ascroll_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(ascroll_item)
		ranscroll = ranscroll + math.random(-40,40)
		player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
		player:EvaluateItems()
		return true
	elseif collectible == soulshave_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(soulshave_item)
		local continueTime = 150 * 30
		soulshaveContinue = Game().TimeCounter + continueTime
		soulshaveuse = true
		timer:Insert(soulshave_item, continueTime, 0, 0, 1)
	elseif collectible == hippo_item then
		if hippoContinue < Game().TimeCounter then
			local continueTime = 2 * 30

			hippoContinue = Game().TimeCounter + continueTime
			isHippoTimeOut = false

			timer:Insert(hippo_item, continueTime, 0.005, 0, 1)
		end
		player:RemoveCollectible(hippo_item)
		player:AddCollectible(114,0,true)
		return true
	elseif collectible == raven_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(raven_item)
		for i = 1, math.random(2,3) do
			Isaac.Spawn(3, 14, 0, Isaac.GetFreeNearPosition(player.Position, 1), Vector(0, 0), player)
		end
		Isaac.Spawn(50, 0, 0, Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
	elseif collectible == toy_item then
		player:AnimateCollectible(collectible, "UseItem", "Idle")
		player:RemoveCollectible(toy_item)
		Isaac.Spawn(5, 100, attacktype[math.random(1,5)], Isaac.GetFreeNearPosition(player.Position, 50), Vector(0, 0), player)
	end
end

ChaosGreed:AddCallback(ModCallbacks.MC_USE_ITEM, ChaosGreed.useItem)

function ChaosGreed:useCard(card) 
  local player = Isaac.GetPlayer(0) 
 
  if card == hermit_stars_card then 
	player:AddCard(Card.CARD_HERMIT)
	player:AddCard(Card.CARD_STARS)
	return true 
  end 
end 

ChaosGreed:AddCallback(ModCallbacks.MC_USE_CARD, ChaosGreed.useCard)

function ChaosGreed:npcHit(dmg_target , dmg_amount, dmg_source, dmg_dealer)
    local player = Isaac.GetPlayer(0)
    local flag = false

    if player:HasCollectible(chiggers_item) and dmg_target:IsVulnerableEnemy() then
        if dmg_dealer.Type == EntityType.ENTITY_TEAR and player.Luck >= 18 then
			local spd = 5.0 + math.random()
			local ang = math.rad(math.random() * 360)
			local s = Game():Spawn(3, 802, dmg_target.Position+Vector(math.cos(ang)*spd,math.sin(ang)*spd), Vector(math.cos(ang)*spd,math.sin(ang)*spd), player, 0, player.InitSeed)
			s.CollisionDamage = dmg_amount * 2
		else
			if dmg_dealer.Type == EntityType.ENTITY_TEAR and math.random(1,19-player.Luck)<=1 then
				local spd = 5.0 + math.random()
				local ang = math.rad(math.random() * 360)
				local s = Game():Spawn(3, 802, dmg_target.Position+Vector(math.cos(ang)*spd,math.sin(ang)*spd), Vector(math.cos(ang)*spd,math.sin(ang)*spd), player, 0, player.InitSeed)
				s.CollisionDamage = dmg_amount * 2
			end
		end
    end

	if player:HasCollectible(325) and dmg_target:IsVulnerableEnemy() then
		if dmg_dealer.Type == EntityType.ENTITY_TEAR and dmg_target:ToNPC():IsChampion() or dmg_target:ToNPC():IsBoss() then
			dmg_target:AddHealth(-player.Damage/2)
		end
	end

	if player:HasCollectible(lol_item) and dmg_target.Type == 306 then
		dmg_target:Kill()
	end


	--[[if player:HasCollectible(63) and dmg_target:IsVulnerableEnemy() then
		if dmg_dealer.Type == EntityType.ENTITY_TEAR and math.random(1,4)==1 then
			player:SetActiveCharge(player:GetActiveCharge() + 1)
		end
	end]]

    if dmg_source == 0 then
        local lvl = Game():GetLevel()
        local amt = dmg_amount
        local l = lvl:GetAbsoluteStage()

        local fin_amt = 1.0 - (l / 12) * 0.4
        --Isaac.DebugString("Original Damage:"..amt..", Reduced Damage:"..(dmg_amount * fin_amt))
        local ref = dmg_target
        --for i=1,#ref do
        --    if Isaac.GetRoomEntities()[i].Index == dmg_target.Index then ref = Isaac.GetRoomEntities()[i] end
        --end

        local d = 1.0

        if player:HasCollectible(chiggers_item) and ref:IsVulnerableEnemy() then
            d = 0.5
        end

        if ref.Type == EntityType.ENTITY_HUSH then fin_amt = 1.5 end

        if ref.Index ~= nil then if ref:IsVulnerableEnemy() then
            ref.HitPoints = ref.HitPoints + (dmg_amount * d) * (1.0-fin_amt)
        end end
    end
end

ChaosGreed:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, ChaosGreed.npcHit)

function ChaosGreed:eterbanjireset()
	local game = Game();
	local room = game:GetRoom();
	local player = Isaac.GetPlayer(0);
	
	if player:HasCollectible(313)==false then
		if eterbanji == 0 and roomiscleared == 1 then
			if not player:GetEffects():GetCollectibleEffect(313) then	
				roomiscleared = 0
				if eterbanji ~= 0 and roomiscleared ~=0 then
					player:GetEffects():AddCollectibleEffect(313,true)
				end
				if roomseedisold ~= room:GetDecorationSeed() then
					roomiscleared = 1
					roomseedisold = room:GetDecorationSeed()
					player:GetEffects():AddCollectibleEffect(313,true)
				end
			end
		end

		if roomseedisold ~= room:GetDecorationSeed() then
			roomiscleared = 0 
			roomseedisold = room:GetDecorationSeed()
		end

		if eterbanji ~= 0 and roomiscleared == 0 then
			eterbanji = eterbanji + 1
			roomiscleared = 1
		end

		if eterbanji > 0 then
			if not player:GetEffects():GetCollectibleEffect(313) then	
				player:GetEffects():AddCollectibleEffect(313,true)
				eterbanji = eterbanji - 1
			end
		end
	elseif player:HasCollectible(313) then
		if eterbanji > 0 then
			if not player:GetEffects():GetCollectibleEffect(313) then	
				player:GetEffects():AddCollectibleEffect(313,true)
				eterbanji = eterbanji - 1
				roomiscleared = 0
			end
		end
	end
end

ChaosGreed:AddCallback(ModCallbacks.MC_POST_UPDATE, ChaosGreed.eterbanjireset);

function ChaosGreed:familiarUpdate(ent)
	local fam = ent:ToFamiliar()
    local player = Isaac.GetPlayer(0)

    if fam.Variant == 802 then
        if fam.FrameCount % 20 == 2 then
            local ents = Isaac.GetRoomEntities()
            for i=1,#ents do
                if ents[i]:IsVulnerableEnemy() then
                    if fam.Target == nil or ents[i].HitPoints > fam.Target.HitPoints then if ents[i].Size > 3 then
                        fam.Target = ents[i]
                    end end
                end
            end
        end
        if fam.FrameCount > 80 then fam:Kill() end
        if fam.Target ~= nil and fam.FrameCount % 2 == 1 or fam.FramCount == 1 then
            fam.Velocity = fam.Velocity + ((fam.Target.Position - fam.Position):Resized(2.65+math.abs(math.cos(fam.FrameCount / 2) * 0.5)))
            fam.Velocity = fam.Velocity * 0.8
        end

        if fam.Target == nil and fam.FrameCount > 30 then fam:Kill() end

        if fam.Velocity:Length() > 8 then fam.Velocity:Resize(8) end

        if fam.FrameCount % 3 == fam.Index % 3 then
            local ents = Isaac.GetRoomEntities()
            for i=1,#ents do
                local off = ents[i].Position - ent.Position
                if ents[i]:IsVulnerableEnemy() and math.abs(off.X) + math.abs(off.Y) < ent.Size+32 and fam.FrameCount > 40 then
                    ent:Kill()
                end
             end
        end
	end
end

ChaosGreed:AddCallback(ModCallbacks.MC_FAMILIAR_UPDATE, ChaosGreed.familiarUpdate)

function ChaosGreed:Render()
	local player = Isaac.GetPlayer(0)
	if player:HasCollectible(backpack_item) and storedItem ~= 0 then
		storedItemSprite:Render(Vector(0,0), Vector(0,0), Vector(0,0))
	end

	-- 타이머 랜더
	timer:Rander()
end

ChaosGreed:AddCallback(ModCallbacks.MC_POST_RENDER, ChaosGreed.Render);